
public class GameofLife {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] before = {
								{" ", " ", " "},
								{" ", " ", " "},
								{"#", "#", "#"},
								{"#", "#", "#"},
								{" ", " ", " "},
								{" ", " ", " "}
							};
		
		String[][] after = {
				{" ", " ", " "},
				{" ", " ", " "},
				{" ", " ", " "},
				{" ", " ", " "},
				{" ", " ", " "},
				{" ", " ", " "}
			};
	
		
		for(int i = 0; i<before.length; i++) {
			for(int j=0; j<before[i].length; j++) {
				int neighbor = 0;
				//before[i][j] left up
				if(i-1>=0 && j-1>=0) {	//left-up exists
					if(before[i-1][j-1].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] up
				if(i-1>=0) {	//up exists
					if(before[i-1][j].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] right up
				if(i-1>=0 && j+1<before[i].length) {	//right up exists
					if(before[i-1][j+1].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] left
				if(j-1>=0) {	//left exists
					if(before[i][j-1].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] right
				if(j+1<before[i].length) {	//right exists
					if(before[i][j+1].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] left down
				if(i+1<before.length && j-1>=0) {	//left down exists
					if(before[i+1][j-1].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] down
				if(i+1<before.length) {	//down exists
					if(before[i+1][j].equals("#")) {
						neighbor++;
					}
				}
				//before[i][j] right down
				if(i+1<before.length && j+1<before[i].length) {	//right down exists
					if(before[i+1][j+1].equals("#")) {
						neighbor++;
					}
				}
				//System.out.print("<" + neighbor + ">");
				if(neighbor < 2) {
					after[i][j] = " ";
				} else if(neighbor==2) {
					after[i][j] = before[i][j];
				} else if(neighbor == 3){
					after[i][j] = "#";
				} else if(neighbor > 3){
					after[i][j] = " ";
				}
				
				System.out.print("[" + after[i][j] + "]");
			}
			
			System.out.println();
		} //for i
		
		
	}

}
